import 'dart:convert';
import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;


Future<String> webRead()
async {
  final response = await http.get(Uri.parse("http://127.0.0.1:5000/hello"));

  if (response.statusCode == 200)
  {
    return response.body;
  }
  else
    {
      print("error");
      return "";
    }
}


