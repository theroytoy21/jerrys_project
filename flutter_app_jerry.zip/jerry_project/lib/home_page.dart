import 'package:flutter/material.dart';
import 'package:jerry_project/detailed_info.dart';
import 'package:jerry_project/test2.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:jerry_project/api.dart';
import 'dart:developer' as dev;
String something = "";
List company = [];

String hello()
{
  return "hello";
}

Future<String> fetch_ESG()
async {
  final company_names = await http.get(Uri.parse("http://10.0.2.2:5000/hello"));

  if (company_names.statusCode == 200)
  {
    return company_names.body;
  }
  else
  {
    print("Unable to connect");
    return "not hello";
  }
}

Future<String> fetch_company()
async {
  final company_names = await http.get(Uri.parse("http://10.0.2.2:5000/hello2"));

  if (company_names.statusCode == 200)
  {
    return company_names.body;
  }
  else
  {
    print("Unable to connect");
    return "not hello";
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override

  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  Future<List> get_company() async
  {
    something = await fetch_company();
    String a = something.replaceAll(",", " ");
    something = a.replaceAll('"', "");
    something = something.replaceAll('[',"");
    something = something.replaceAll(']',"");
    something = something.replaceAll("\n","");
    List companies = something.split(" ");
    companies.removeLast();
    return companies;
  }

  Future<List> get_ESG() async
  {
    something = await fetch_ESG();
    String a = something.replaceAll(",", " ");
    something = a.replaceAll('"', "");
    something = something.replaceAll('[',"");
    something = something.replaceAll(']',"");
    something = something.replaceAll("\n","");
    List esg = something.split(" ");
    print(esg);
    return esg;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text("ESG Predictions"),
        actions: <Widget>[
          // ElevatedButton(
          //     onPressed: () {
          //       Navigator.of(context).push(MaterialPageRoute(builder: (context) => const detailed_info()));
          //     },
          //     child: Text("Pizza")
          // ),
          IconButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => detailed_info()),);
                },
              icon: const Icon(Icons.search_rounded))
        ],
      ),
      body: FutureBuilder(
        builder: (BuildContext context, AsyncSnapshot<List<dynamic>> snapshot) {
          if (snapshot.connectionState == ConnectionState.done)
            {
              if(snapshot.hasError)
                {
                  return Center(
                    child:

                    Text("Error has occured",
                    style: TextStyle(fontSize: 18),
                    ),
                  );
                }
              else if(snapshot.hasData)
                {
                  final data1 = snapshot.data![0] as List<String>;
                  final data2 = snapshot.data![1] as List<String>;
                  return ListView.builder(
                      itemCount: data1.length,
                      itemBuilder: (context, index)
                  {
                    return ListTile(

                      title: Text(data1[index]),
                          subtitle: Text("Predicted ESG Score: " + data2[index]),
                    );
                  });
                }
            }
          return Center(
            child: CircularProgressIndicator(),
          );
      },
        future: Future.wait([get_company(),get_ESG()])
      )

      // Padding(
      //   padding: const EdgeInsets.all(20),
      //   child: Column(
      //     mainAxisAlignment: MainAxisAlignment.center,
      //     children: [
      //       DataTable(
      //           columns: const <DataColumn>[
      //             DataColumn(
      //                 label: Expanded(
      //                     child: Text(
      //                       'Name',
      //                       style: TextStyle(fontStyle: FontStyle.italic),
      //                     )
      //                 )
      //             ),
      //             DataColumn(
      //                 label: Expanded(
      //                     child: Text(
      //                         "Stock Ticker",
      //                         style: TextStyle(fontStyle: FontStyle.italic)
      //                     )
      //                 )
      //             ),
      //
      //             DataColumn(
      //                 label: Expanded(
      //                   child: Text("ESG Score")
      //                 )
      //             )
      //           ], rows: const <DataRow>[
      //         DataRow(
      //           // add companies and icons here
      //             cells: <DataCell>[
      //               DataCell(Text("")),
      //               DataCell(Text("AAPL")),
      //               DataCell(Text("80")),
      //             ]
      //         )
      //       ]
      //       )
      //     ],
      //   ),
      //   )
      );
  }
}

