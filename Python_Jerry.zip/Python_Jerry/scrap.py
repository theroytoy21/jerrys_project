import requests
import pandas as pd
from textblob import TextBlob
import csv
import datetime
from esg_info import esg_getter
from esg_info import save_sp500_tickers

def main(company):
    payload = {
        'api_key': 'a9bb3b013dc69aa7aadd21b80e0bdc56',
        'query': company,
        'num': '10',
        'time_period': '1D'
    }

    response = requests.get('https://api.scraperapi.com/structured/twitter/search', params=payload)
    data = response.json()

    all_tweets = data['organic_results']
    twitter_data = []
    # print(all_tweets)
    for tweet in all_tweets:
        print(tweet["snippet"].split("— "))
        twitter_data.append(tweet["snippet"].split("— ")[0])
        
    # sentiment_list = []
    # for text in twitter_data:
    #     sentiment_list.append(get_sentiment(preprocess_text(str(text))))
    sentiment_list = get_sentiment(preprocess_text(twitter_data))
    print(sentiment_list)

    with open("training_data.csv", 'a', newline="") as csvfile:
        writer = csv.writer(csvfile)
        # writer.writerow(["Tweet Count","Sentiment","Positive","Negative","Neutral","Date(UTC)","Company Name","ESG"])
        writer.writerow([
                        str(len(twitter_data)),
                        str(max_sentiment(sentiment_list)),
                        str(sentiment_list[0]),
                        str(sentiment_list[1]),
                        str(sentiment_list[2]),
                        str(date),
                        str(payload['query']),
                        str(esg_getter(payload['query']))
                        ])

def preprocess_text(list):
    for tweet in list:
        str(tweet.lower().split())
    return list

def get_sentiment(list):
    positive = 0
    negative = 0
    neutral = 0
    for tweet in list:
        blob = TextBlob(str(tweet))
        polarity = blob.sentiment.polarity
        if polarity > 0:
            print("p")
            positive += 1
        elif polarity < 0:
            print("neg")
            negative += 1
        else:
            print("n")
            neutral += 1
    return [positive, negative, neutral]

def max_sentiment(list):
    if (list[0] >= list[1]) and (list[0] >= list[2]):
        return "positive"
    elif (list[1] >= list[0]) and (list[1] >= list[2]):
        return "negative"
    else:
        return "neutral"


    # df = pd.DataFrame(twitter_data)

    # chart = df.head(int(payload['num']))
    # print(chart)

def real_main():
    companys = save_sp500_tickers()
    for company in companys:
        main(company)

# date = str((datetime.datetime.utcnow()).strftime("%Y-%m-%d"))
# with open("training_data.csv", 'r') as csvfile:
#     file = csv.reader(csvfile)
#     latest_date = csvfile.readlines()[-1]
#     if latest_date.find(date) == -1:
#         real_main()
#     else:
#         print("Already searched today.")

apple = ["Don't look down", 
"Over the past 20 years, whenever $AAPL dropped 10% or more in a quarter, the stock gained an average of 10% in the following 3-months. And Apple's median return was 14% following a 10%+ decline.",
"I want to like this wallpaper but I just can’t. It’s fugly.",
"Nothing but bad news for $AAPL lately",
"Silver iPads in white keyboard cases is such a good look"]

tesla = ["$TSLA More bad news for Tesla. 60 Minutes is going to air on Sunday, March 31st about FSD investigation.",
"$TSLA engineers don’t have engineering degrees or even common sense apparently.",
"$TSLA WILL COLLAPSE",
"Why I have never been more excited about $TSLA",
"$TSLA Cybertruck is still the UGLIEST and most OVERPRICED vehicle ever made."]

nvidia = ["Trying to overcome the resistance from 2000 no deterioration in outlook still very strong",
"#NVDA Nearing the $970 upside target.",
"This announcement might eventually result in an outright ban on Nvidia exports.",
"IDK ABOUT YALL BUT I LIKE #NVDA RIGHT HERE, looks like we could get a nice leg up later today or tmrw.",
"A few days ago we suggested that NVDA was about to move down. In today's overview we will evaluate its readiness for a deeper move."]

intel = ["I like Intel $INTC for a bit of upside after the false break and reclaim of local support.",
"China blocks use of $AMD and $INTC in government computers.",
"In the rapidly evolving world of artificial intelligence, $INTC has been making significant strides to challenge $NVDA dominance in the AI accelerator market.",
"Watching #Intel",
"I like the Risk to Reward on $INTC"]

print(get_sentiment(preprocess_text(apple)))
print(get_sentiment(preprocess_text(tesla)))
print(get_sentiment(preprocess_text(nvidia)))
print(get_sentiment(preprocess_text(intel)))