import finnhub
import csv
import datetime


def create_csv():
    finnhub_client = finnhub.Client(api_key="coctna9r01qknpft9at0coctna9r01qknpft9atg")
    # companies = finnhub_client.stock_symbols('US')
    companies = ["TSLA", "AAPL", "GOOG", "AMZN", "MSFT"]  

    h = ["current_price","change","percent_change",
    "high_price_of_the_day","low_price_of_the_day",
    "open_price_of_the_day","previous_close_price",
    "date","ticker"]
    final = []
    company_list = []
    for company in companies:
        dict = finnhub_client.quote(company)
        print(dict)
        with open("wasd.csv", "a", newline="") as csvfile:
            writer = csv.writer(csvfile)
            # writer.writerow(h)
            dict.pop("t")
            dict["ticker"] = company
            dict["date"] = str((datetime.datetime.utcnow()).strftime("%Y-%m-%d"))
            company_list.append(dict)
            writer.writerow(dict.values())
            # data = list(dict.values())
            # data.pop()
            # data.append(str((datetime.datetime.utcnow()).strftime("%Y-%m-%d")))
            # data.append(company)
            # final.append(data)
            # writer.writerows(final)
    return company_list

def return_info():
    finnhub_client = finnhub.Client(api_key="coctna9r01qknpft9at0coctna9r01qknpft9atg")
    # companies = finnhub_client.stock_symbols('US')
    companies = ["TSLA", "AAPL", "GOOG", "AMZN", "MSFT"]  

    h = ["current_price","change","percent_change",
    "high_price_of_the_day","low_price_of_the_day",
    "open_price_of_the_day","previous_close_price",
    "date","ticker"]
    final = []
    company_list = []
    for company in companies:
        dict = finnhub_client.quote(company)
        dict.pop("t")
        dict["ticker"] = company
        dict["date"] = str((datetime.datetime.utcnow()).strftime("%Y-%m-%d"))
        company_list.append(dict)


    for x in company_list:
        a = {}
        a["current price"] = x.pop('c')
        a["change"] = x.pop('d')
        a["percent change"] = x.pop('dp')
        a["high price of the day"] = x.pop('h')
        a["ow price of the day"] = x.pop('l')
        a["open price of the day"] = x.pop('o')
        a["previous close price"] = x.pop('pc')
        a["last_updated"] = str((datetime.datetime.utcnow()).strftime("%Y-%m-%d"))
        a["ticker"] = x.pop('ticker')
        final.append(a)
    return final
