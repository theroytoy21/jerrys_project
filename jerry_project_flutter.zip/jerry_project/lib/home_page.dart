import 'package:flutter/material.dart';
import 'package:jerry_project/detailed_info.dart';
import 'package:jerry_project/test2.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:developer' as dev;
import "package:intl/intl.dart";

String something = "";
List company = [];

Future<String> fetch_ESG()
async
{
  final company_names = await http.get(Uri.parse("http://10.0.2.2:5000/ESG")).timeout(Duration(seconds: 10));

  if (company_names.statusCode == 200)
  {
    return company_names.body;
  }
  else
  {
    print("Unable to connect");
    return "not hello";
  }
}

Future<String> fetch_company()
async
{
  final company_names = await http.get(Uri.parse("http://10.0.2.2:5000/COMPANY")).timeout(Duration(seconds: 10));

  if (company_names.statusCode == 200)
  {
    return company_names.body;
  }
  else
  {
    print("Unable to connect");
    return "not hello";
  }
}

Future<List<dynamic>> fetchDetails() async
{
  final response = await http.get(Uri.parse("http://10.0.2.2:5000/details")).timeout(Duration(seconds: 10));
  if(response.statusCode == 200)
  {
    return json.decode(response.body);
  }
  else
  {
    throw Exception("Unable to connect");
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override

  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage>
{

  Future<List> get_company() async
  {
    something = await fetch_company();
    String a = something.replaceAll(",", " ");
    something = a.replaceAll('"', "");
    something = something.replaceAll('[',"");
    something = something.replaceAll(']',"");
    something = something.replaceAll("\n","");
    List companies = something.split(" ");
    companies.removeLast();
    return companies;
  }

  Future<List> get_ESG() async
  {
    something = await fetch_ESG();
    var esg = json.decode(something).cast<String>().toList();
    return esg;
  }

  @override
  Widget build(BuildContext context)
  {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text("ESG Predictions"),
        actions: <Widget>[
          IconButton(
              onPressed: ()
              {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => detailed_info()),);
                },
              icon: const Icon(Icons.search_rounded))
        ],
      ),
      body: FutureBuilder(
        builder: (BuildContext context, AsyncSnapshot<List<dynamic>> snapshot) {
          if (snapshot.connectionState == ConnectionState.done)
            {
              if(snapshot.hasError)
                {
                  return Center(
                    child:
                      Text("Error has occurred",
                      style: TextStyle(fontSize: 18),
                    ),
                  );
                }
              else if(snapshot.hasData)
                {
                  final data1 = snapshot.data![0] as List<String>;
                  final data2 = snapshot.data![1] as List<String>;
                  return ListView.builder(
                      itemCount: data1.length,
                      itemBuilder: (context, index)
                  {
                    return ListTile(
                      title: Text(data1[index]),
                          subtitle: Text("Predicted ESG Score: " + data2[index]),
                      onTap: (){
                        List<dynamic> dataList = snapshot.data as List<dynamic>;
                        Navigator.push(context,
                        MaterialPageRoute(builder: (context) => DataDisplayPage(item: data1[index]),
                        ),
                        );
                      },
                    );
                  });
                }
            }
          return Center(
            child: CircularProgressIndicator(),
          );
      },
        future: Future.wait([get_company(),get_ESG()])
      )
      );
  }
}

class DataDisplayPage extends StatefulWidget
{
  final String item;

  DataDisplayPage({required this.item});
  @override
  _DataDisplayPageState createState() => _DataDisplayPageState();
}

class _DataDisplayPageState extends State<DataDisplayPage>
{
  List<dynamic> dataList = [];

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    final response = await http.get(Uri.parse("http://10.0.2.2:5000/details")).timeout(Duration(seconds: 10));
    if (response.statusCode == 200) {
      setState(() {
        dataList = json.decode(response.body);
        final list = dataList.where((item)
        {
          final name = item["ticker"];
          return name.contains(widget.item);
        }).toList();

        dataList = list;
        dataList[0].remove("ticker");
      });
    } else {
      throw Exception('Failed to load data');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text('More information of ${widget.item}'),
      ),
      body: ListView.builder(
        itemCount: dataList.length,
        itemBuilder: (context, index) {
          final item = dataList[0];
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: item.entries.map<Widget>((entry) {
              return ListTile(
                title: Text("${entry.key}"),
                subtitle: Text("${entry.value}"),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}