import 'package:flutter/material.dart';
class detailed_info extends StatefulWidget {
  const detailed_info({super.key});

  @override
  State<detailed_info> createState() => _detailed_infoState();
}

class _detailed_infoState extends State<detailed_info> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title:Text("Search for company")
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
        children: [
          TextField(
            obscureText: false,
            decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Search"
            ),
            onChanged: (String s){
              print("Searched: s");
            },

            ),
          ],
        )
      )
    );
  }
}
