import 'package:flutter/material.dart';
import 'package:jerry_project/home_page.dart';

class AnotherPage extends StatefulWidget {
  const AnotherPage({super.key});

  @override
  State<AnotherPage> createState() => _AnotherPageState();
}

class _AnotherPageState extends State<AnotherPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          title: Text("Detailed Information"),
      ),
      body: Column(
        children: [
          ElevatedButton(onPressed: () {Navigator.of(context).push(MaterialPageRoute(builder: (context) => const HomePage()));
            }, child: Text("Go to Home Page"))
        ],
      ),
    );
  }
}

